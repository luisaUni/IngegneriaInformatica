var searchData=
[
  ['cercacontatto_0',['cercaContatto',['../classit_1_1unisa_1_1diem_1_1progettoinf_1_1gruppo25_1_1model_1_1_rubrica.html#a05e0377d77651dfd37513677e0ee5c01',1,'it.unisa.diem.progettoinf.gruppo25.model.Rubrica.cercaContatto()'],['../interfaceit_1_1unisa_1_1diem_1_1progettoinf_1_1gruppo25_1_1model_1_1_rubrica_interface.html#af8debba739f4807879c36b14ec3d8b69',1,'it.unisa.diem.progettoinf.gruppo25.model.RubricaInterface.cercaContatto()']]],
  ['contatto_1',['Contatto',['../classit_1_1unisa_1_1diem_1_1progettoinf_1_1gruppo25_1_1model_1_1_contatto.html#aeef066bdd150165180317fba8ffec162',1,'it::unisa::diem::progettoinf::gruppo25::model::Contatto']]],
  ['contattocontroller_2',['ContattoController',['../classit_1_1unisa_1_1diem_1_1progettoinf_1_1gruppo25_1_1controller_1_1_contatto_controller.html#ab973002a507847d822e38236e7770be0',1,'it::unisa::diem::progettoinf::gruppo25::controller::ContattoController']]]
];
