var searchData=
[
  ['rubrica_0',['Rubrica',['../classit_1_1unisa_1_1diem_1_1progettoinf_1_1gruppo25_1_1model_1_1_rubrica.html',1,'it::unisa::diem::progettoinf::gruppo25::model']]],
  ['rubricainterface_1',['RubricaInterface',['../interfaceit_1_1unisa_1_1diem_1_1progettoinf_1_1gruppo25_1_1model_1_1_rubrica_interface.html',1,'it::unisa::diem::progettoinf::gruppo25::model']]]
];
