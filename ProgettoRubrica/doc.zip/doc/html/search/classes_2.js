var searchData=
[
  ['elencocontroller_0',['ElencoController',['../classit_1_1unisa_1_1diem_1_1progettoinf_1_1gruppo25_1_1controller_1_1_elenco_controller.html',1,'it::unisa::diem::progettoinf::gruppo25::controller']]],
  ['elencoview_1',['ElencoView',['../classit_1_1unisa_1_1diem_1_1progettoinf_1_1gruppo25_1_1view_1_1_elenco_view.html',1,'it::unisa::diem::progettoinf::gruppo25::view']]]
];
