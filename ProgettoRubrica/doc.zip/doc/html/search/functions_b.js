var searchData=
[
  ['testapp_0',['testApp',['../classcom_1_1example_1_1_app_test.html#a4e1b7d9f989f8a307603d060cc3b5e73',1,'com::example::AppTest']]],
  ['tostring_1',['toString',['../classit_1_1unisa_1_1diem_1_1progettoinf_1_1gruppo25_1_1model_1_1_rubrica.html#a9086c58236d5f27e8f79e247cdf6de23',1,'it::unisa::diem::progettoinf::gruppo25::model::Rubrica']]]
];
