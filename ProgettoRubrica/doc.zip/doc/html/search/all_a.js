var searchData=
[
  ['scrivicsv_0',['scriviCSV',['../classit_1_1unisa_1_1diem_1_1progettoinf_1_1gruppo25_1_1model_1_1_gestore_file.html#a1790a8053c6021a349cb7865b9c3a45b',1,'it::unisa::diem::progettoinf::gruppo25::model::GestoreFile']]],
  ['setcognome_1',['setCognome',['../classit_1_1unisa_1_1diem_1_1progettoinf_1_1gruppo25_1_1model_1_1_contatto.html#a8d53c675a2b6386086474daa733dd5f7',1,'it::unisa::diem::progettoinf::gruppo25::model::Contatto']]],
  ['setemail1_2',['setEmail1',['../classit_1_1unisa_1_1diem_1_1progettoinf_1_1gruppo25_1_1model_1_1_contatto.html#a0b39f9d58138e96eccf66a5c6d763fa2',1,'it::unisa::diem::progettoinf::gruppo25::model::Contatto']]],
  ['setemail2_3',['setEmail2',['../classit_1_1unisa_1_1diem_1_1progettoinf_1_1gruppo25_1_1model_1_1_contatto.html#a08f4cdcc611c8cf7f38dad4c3ef63646',1,'it::unisa::diem::progettoinf::gruppo25::model::Contatto']]],
  ['setemail3_4',['setEmail3',['../classit_1_1unisa_1_1diem_1_1progettoinf_1_1gruppo25_1_1model_1_1_contatto.html#af1386b0fade0e9ec83b9c02c030d0c21',1,'it::unisa::diem::progettoinf::gruppo25::model::Contatto']]],
  ['setnome_5',['setNome',['../classit_1_1unisa_1_1diem_1_1progettoinf_1_1gruppo25_1_1model_1_1_contatto.html#a47f7b0fddf9ddaa8bee0870a69d6c27c',1,'it::unisa::diem::progettoinf::gruppo25::model::Contatto']]],
  ['setnumero1_6',['setNumero1',['../classit_1_1unisa_1_1diem_1_1progettoinf_1_1gruppo25_1_1model_1_1_contatto.html#af338b025cffd6d61bbc9919dcd211f2e',1,'it::unisa::diem::progettoinf::gruppo25::model::Contatto']]],
  ['setnumero2_7',['setNumero2',['../classit_1_1unisa_1_1diem_1_1progettoinf_1_1gruppo25_1_1model_1_1_contatto.html#ae9469e7a2d3b45087646313fce502898',1,'it::unisa::diem::progettoinf::gruppo25::model::Contatto']]],
  ['setnumero3_8',['setNumero3',['../classit_1_1unisa_1_1diem_1_1progettoinf_1_1gruppo25_1_1model_1_1_contatto.html#a45b17e9c999f005abcb3badc0ef63964',1,'it::unisa::diem::progettoinf::gruppo25::model::Contatto']]],
  ['setpreferito_9',['setPreferito',['../classit_1_1unisa_1_1diem_1_1progettoinf_1_1gruppo25_1_1model_1_1_contatto.html#adba95dfff9fef0acd8e1b2fd4f9df06f',1,'it::unisa::diem::progettoinf::gruppo25::model::Contatto']]],
  ['start_10',['start',['../classit_1_1unisa_1_1diem_1_1progettoinf_1_1gruppo25_1_1app_1_1_applicazione.html#a90002e051de3aa3ba69ae286ef8ade45',1,'it::unisa::diem::progettoinf::gruppo25::app::Applicazione']]],
  ['suite_11',['suite',['../classcom_1_1example_1_1_app_test.html#a2c1e39de607b4fc0e74d1b30e710ac78',1,'com::example::AppTest']]]
];
