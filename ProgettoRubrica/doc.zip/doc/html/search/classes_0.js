var searchData=
[
  ['applicazione_0',['Applicazione',['../classit_1_1unisa_1_1diem_1_1progettoinf_1_1gruppo25_1_1app_1_1_applicazione.html',1,'it::unisa::diem::progettoinf::gruppo25::app']]],
  ['apptest_1',['AppTest',['../classcom_1_1example_1_1_app_test.html',1,'com::example']]]
];
