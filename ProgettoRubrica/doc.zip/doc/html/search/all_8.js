var searchData=
[
  ['ordina_0',['ordina',['../classit_1_1unisa_1_1diem_1_1progettoinf_1_1gruppo25_1_1model_1_1_rubrica.html#ab0a9eaa255cc04a1fb0da9bc475f7c2d',1,'it.unisa.diem.progettoinf.gruppo25.model.Rubrica.ordina()'],['../interfaceit_1_1unisa_1_1diem_1_1progettoinf_1_1gruppo25_1_1model_1_1_rubrica_interface.html#a7a81499c973917e491e01bc8ecfb101f',1,'it.unisa.diem.progettoinf.gruppo25.model.RubricaInterface.ordina()']]]
];
