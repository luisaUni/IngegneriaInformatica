var searchData=
[
  ['getcognome_0',['getCognome',['../classit_1_1unisa_1_1diem_1_1progettoinf_1_1gruppo25_1_1model_1_1_contatto.html#a7989716a46afaba24f390cbafa06442f',1,'it::unisa::diem::progettoinf::gruppo25::model::Contatto']]],
  ['getemail1_1',['getEmail1',['../classit_1_1unisa_1_1diem_1_1progettoinf_1_1gruppo25_1_1model_1_1_contatto.html#a023fd7a16d5e6dd75eff02cd4be01ede',1,'it::unisa::diem::progettoinf::gruppo25::model::Contatto']]],
  ['getemail2_2',['getEmail2',['../classit_1_1unisa_1_1diem_1_1progettoinf_1_1gruppo25_1_1model_1_1_contatto.html#a477d65736e274cb6e05ab9d5d21aae42',1,'it::unisa::diem::progettoinf::gruppo25::model::Contatto']]],
  ['getemail3_3',['getEmail3',['../classit_1_1unisa_1_1diem_1_1progettoinf_1_1gruppo25_1_1model_1_1_contatto.html#a51c607aaf3260d82c2297381af969bb5',1,'it::unisa::diem::progettoinf::gruppo25::model::Contatto']]],
  ['getnome_4',['getNome',['../classit_1_1unisa_1_1diem_1_1progettoinf_1_1gruppo25_1_1model_1_1_contatto.html#addd31fbd4615ec12fdc7d83e7e8f506a',1,'it::unisa::diem::progettoinf::gruppo25::model::Contatto']]],
  ['getnumero1_5',['getNumero1',['../classit_1_1unisa_1_1diem_1_1progettoinf_1_1gruppo25_1_1model_1_1_contatto.html#addd0762a2405a77f254d28928ce139c7',1,'it::unisa::diem::progettoinf::gruppo25::model::Contatto']]],
  ['getnumero2_6',['getNumero2',['../classit_1_1unisa_1_1diem_1_1progettoinf_1_1gruppo25_1_1model_1_1_contatto.html#a9ce52feecc76dd8f93e96879cc349639',1,'it::unisa::diem::progettoinf::gruppo25::model::Contatto']]],
  ['getnumero3_7',['getNumero3',['../classit_1_1unisa_1_1diem_1_1progettoinf_1_1gruppo25_1_1model_1_1_contatto.html#a0c81f341769d2dc9144383bf5f8e7ab5',1,'it::unisa::diem::progettoinf::gruppo25::model::Contatto']]]
];
