var searchData=
[
  ['main_0',['main',['../classit_1_1unisa_1_1diem_1_1progettoinf_1_1gruppo25_1_1app_1_1_applicazione.html#a2736006175f6dd90a6f32d9cb17d640c',1,'it::unisa::diem::progettoinf::gruppo25::app::Applicazione']]]
];
