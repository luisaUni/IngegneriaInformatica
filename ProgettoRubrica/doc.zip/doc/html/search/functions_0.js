var searchData=
[
  ['aggiungicontatto_0',['aggiungiContatto',['../classit_1_1unisa_1_1diem_1_1progettoinf_1_1gruppo25_1_1model_1_1_rubrica.html#a5e20d4186202a305f79b4cf831cb4460',1,'it.unisa.diem.progettoinf.gruppo25.model.Rubrica.aggiungiContatto()'],['../interfaceit_1_1unisa_1_1diem_1_1progettoinf_1_1gruppo25_1_1model_1_1_rubrica_interface.html#a869f3d3df4e83ec2803ab04788609995',1,'it.unisa.diem.progettoinf.gruppo25.model.RubricaInterface.aggiungiContatto()']]],
  ['apptest_1',['AppTest',['../classcom_1_1example_1_1_app_test.html#af2fad135d435e288c146094c87fac6f1',1,'com::example::AppTest']]]
];
