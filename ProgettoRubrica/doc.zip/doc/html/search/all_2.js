var searchData=
[
  ['displaycontatto_0',['displayContatto',['../classit_1_1unisa_1_1diem_1_1progettoinf_1_1gruppo25_1_1view_1_1_contatto_view.html#ad629f01dd893293aaaf0420bcf8e0cad',1,'it::unisa::diem::progettoinf::gruppo25::view::ContattoView']]],
  ['displayelenco_1',['displayElenco',['../classit_1_1unisa_1_1diem_1_1progettoinf_1_1gruppo25_1_1view_1_1_elenco_view.html#a86f877d276321d1dec76608e34e0ebd7',1,'it::unisa::diem::progettoinf::gruppo25::view::ElencoView']]]
];
