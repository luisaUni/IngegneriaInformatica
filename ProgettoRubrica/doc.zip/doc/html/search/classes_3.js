var searchData=
[
  ['gestorefile_0',['GestoreFile',['../classit_1_1unisa_1_1diem_1_1progettoinf_1_1gruppo25_1_1model_1_1_gestore_file.html',1,'it::unisa::diem::progettoinf::gruppo25::model']]]
];
