var searchData=
[
  ['leggicsv_0',['leggiCSV',['../classit_1_1unisa_1_1diem_1_1progettoinf_1_1gruppo25_1_1model_1_1_gestore_file.html#a79e59bbb649b283c21e42c61a21f78e8',1,'it::unisa::diem::progettoinf::gruppo25::model::GestoreFile']]]
];
