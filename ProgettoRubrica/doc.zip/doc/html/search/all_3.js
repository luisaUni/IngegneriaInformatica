var searchData=
[
  ['elencocontroller_0',['ElencoController',['../classit_1_1unisa_1_1diem_1_1progettoinf_1_1gruppo25_1_1controller_1_1_elenco_controller.html',1,'it.unisa.diem.progettoinf.gruppo25.controller.ElencoController'],['../classit_1_1unisa_1_1diem_1_1progettoinf_1_1gruppo25_1_1controller_1_1_elenco_controller.html#abf98bca137f34028a726ae8c7ca2466a',1,'it.unisa.diem.progettoinf.gruppo25.controller.ElencoController.ElencoController()']]],
  ['elencoview_1',['ElencoView',['../classit_1_1unisa_1_1diem_1_1progettoinf_1_1gruppo25_1_1view_1_1_elenco_view.html',1,'it::unisa::diem::progettoinf::gruppo25::view']]],
  ['eliminacontatto_2',['eliminaContatto',['../classit_1_1unisa_1_1diem_1_1progettoinf_1_1gruppo25_1_1model_1_1_rubrica.html#ac6e1486c429d289a744a987888846b30',1,'it.unisa.diem.progettoinf.gruppo25.model.Rubrica.eliminaContatto()'],['../interfaceit_1_1unisa_1_1diem_1_1progettoinf_1_1gruppo25_1_1model_1_1_rubrica_interface.html#af965d7922fb93c37488f26574b7f5e13',1,'it.unisa.diem.progettoinf.gruppo25.model.RubricaInterface.eliminaContatto()']]]
];
